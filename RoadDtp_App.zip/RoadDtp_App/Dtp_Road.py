import pandas as pd
import streamlit as st
from catboost import CatBoostClassifier
import time
import os
import joblib
import folium
from streamlit_folium import st_folium
import plotly.express as px
from folium.plugins import HeatMap

# Загрузка модели и кодировщиков
model = CatBoostClassifier()
model.load_model("model_catboost.cbm")
le_light = joblib.load("le_light.pkl")
le_weather = joblib.load("le_weather.pkl")
le_road = joblib.load("le_road.pkl")
le_region = joblib.load("le_region.pkl")
le_severity = joblib.load("le_severity.pkl")
@st.cache_data
def load_map(path):
    return pd.read_csv(path)


# Интерфейс Streamlit
st.set_page_config(page_title="Оценка ДТП", layout="wide")
st.title("Приложение: Прогноз и карта ДТП")

tab1, tab2 = st.tabs(["Прогноз ДТП", "Карта ДТП и графики"])

# Вкладка 1 
with tab1:
    st.header("Прогноз тяжести ДТП")
    month = st.selectbox("Месяц", list(range(1, 13)))
    light = st.selectbox("Освещение", le_light.classes_)
    weather = st.selectbox("Погода", le_weather.classes_)
    road = st.selectbox("Тип покрытия", le_road.classes_)
    region = st.selectbox("Регион", le_region.classes_)

    threshold = st.slider("Порог для опасного ДТП (%)", min_value=0, max_value=100, value=50)

    if st.button("Предсказать тяжесть ДТП"):
        input_df = pd.DataFrame([{
            'month': month,
            'light': le_light.transform([light])[0],
            'weather': le_weather.transform([weather])[0],
            'road_type_simple': le_road.transform([road])[0],
            'region': le_region.transform([region])[0]
        }])

        proba = model.predict_proba(input_df)[0]
        danger_proba = proba[le_severity.transform(['Опасный'])[0]] * 100
        st.write(f"Вероятность тяжёлого ДТП: **{danger_proba:.1f}%**")

        if danger_proba >= threshold:
            st.error("ДТП может быть тяжёлым!")
        else:
            st.success("Вероятность тяжёлого ДТП низкая.")

        pred = model.predict(input_df)
        label = le_severity.inverse_transform(pred)[0]
        st.caption(f"Класс по модели: **{label}**")

# Вкладка 2 
with tab2:
    st.header("Карта и статистика ДТП")

    view_mode = st.radio("Выберите режим:", ["Карта", "Графики"], horizontal=True)

    if view_mode == "Карта":
        mode = st.radio("Режим карты:", ["По годам", "По типам ДТП"], horizontal=True)

        if mode == "По годам":
            year_files = sorted([f for f in os.listdir("maps_by_year") if f.endswith(".csv")])
            years = [f.split("_")[1].split(".")[0] for f in year_files]
            selected_year = st.selectbox("Выберите год", years)

            try:
                df_map = load_map(f"maps_by_year/map_{selected_year}.csv")
            except Exception as e:
                st.error(f"Ошибка при загрузке карты за {selected_year}: {e}")
                df_map = None

        else:
            type_files = sorted([f for f in os.listdir("maps_by_type") if f.endswith(".csv")])
            types = [f.replace("map_", "").replace(".csv", "").replace("_", " ") for f in type_files]
            selected_type = st.selectbox("Выберите тип ДТП", types)

            filename = f"map_{selected_type.replace(' ', '_')}.csv"
            df_map = load_map(f"maps_by_type/{filename}")
            try:
                df_map = pd.read_csv(f"maps_by_type/{filename}")
            except Exception as e:
                st.error(f"Ошибка при загрузке карты типа {selected_type}: {e}")
                df_map = None

        if df_map is not None:
            df_sample = df_map.sample(min(3000, len(df_map)), random_state=42)

            color_map = {
                "Красный": "red",
                "Жёлтый": "orange",
                "Зелёный": "green"
            }

            center_lat = df_sample["lat_round"].mean()
            center_lon = df_sample["lon_round"].mean()

            m = folium.Map(location=[center_lat, center_lon], zoom_start=4.5)

            for _, row in df_sample.iterrows():
                folium.CircleMarker(
                    location=[row["lat_round"], row["lon_round"]],
                    radius=4,
                    popup=f"Регион: {row['region']}\nУровень: {row['level']}",
                    color=color_map.get(row["level"], "gray"),
                    fill=True,
                    fill_color=color_map.get(row["level"], "gray"),
                    fill_opacity=0.6,
                ).add_to(m)

            st_folium(m, width=2000, height=1000)

    elif view_mode == "Графики":
        st.subheader("Графики по ДТП")

        option = st.selectbox("Выберите график", [
            "По месяцам",
            "По погоде",
            "По освещению",
            "По регионам"
        ])

        file_map = {
            "По месяцам": "stats_by_month.csv",
            "По погоде": "stats_by_weather.csv",
            "По освещению": "stats_by_light.csv",
            "По регионам": "stats_by_region.csv"
        }

        try:
            df_stats = pd.read_csv(file_map[option])
            df_stats = df_stats.fillna(0).sort_values(by=df_stats.columns[0])

            df_stats = df_stats.rename(columns={
                "Лёгкий": "Лёгкие",
                "Опасный": "Опасные"
            })
            df_stats["Категория"] = df_stats[df_stats.columns[0]]

            df_melted = df_stats.melt(id_vars="Категория", value_vars=["Лёгкие", "Опасные"],
                                      var_name="Тип", value_name="Количество")

            fig = px.bar(df_melted, x="Категория", y="Количество", color="Тип", barmode="group",
                         labels={"Категория": option.replace("По ", "")})

            st.plotly_chart(fig, use_container_width=True)

        except Exception as e:
            st.error(f"Ошибка при загрузке графика: {e}")
        



st.markdown("---")

if st.button("Завершить работу приложения"):
    st.write("Приложение завершено.")
    time.sleep(1)
    os._exit(0)
